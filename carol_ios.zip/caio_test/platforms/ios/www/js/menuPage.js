var exitLink = document.querySelector("#exitLink");
exitLink.addEventListener("click", function(){
    window.localStorage.setItem('user', "");

});
